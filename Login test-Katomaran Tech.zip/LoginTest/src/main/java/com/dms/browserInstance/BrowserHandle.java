package com.dms.browserInstance;

import java.time.Duration;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dms.logs.Logs;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserHandle extends Logs {
	public WebDriver driver;
	public static WebDriverWait wait ;
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();

	public WebDriver settingBrowser(String browser) {
		logger.info("Setting Up "+browser+" ");

		if (browser.equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--remote-allow-origins=*");
			//options. addArguments("--headless");
			WebDriver driver = new ChromeDriver(options);
			tlDriver.set(driver);

		} 
		
		else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			 FirefoxOptions options = new FirefoxOptions();
			 options.addArguments("--remote-allow-origins=*");
			//options. addArguments("--headless");
			tlDriver.set(new FirefoxDriver(options));
		} 
		else if (browser.equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			EdgeOptions options = new EdgeOptions();
			options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			options.addArguments("--remote-allow-origins=*");
			//options. addArguments("--headless");
			tlDriver.set(new EdgeDriver(options));
		} 
		else {
			System.out.println("Please pass the correct browser value : " + browser);
		}
		 wait = new WebDriverWait(getDriver(),Duration.ofSeconds(60));

		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
		getDriver().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(100));
		
		return getDriver();
		
	}

	public static synchronized WebDriver getDriver() {
		return tlDriver.get();
	}
	
		
	
	
}
