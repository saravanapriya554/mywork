package com.dms.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.dms.utils.PageUtil;

public class LoginPOM {
	public WebElement email() {
		return PageUtil.findBy(By.id("user_name"));
	}

	public WebElement password() {
		return PageUtil.findBy(By.id("password"));
	}
	
	public WebElement forgotPasswordLink() {
		return PageUtil.findBy(By.xpath("//a[text()='Forgot Password?']"));
	}
	
	public WebElement loginButton() {
		return PageUtil.findBy(By.xpath("//button/span[text()='Login']"));
	}
	
	
	public WebElement accessDenied(){
		return PageUtil.findBy(By.xpath("//div[text()='Access Denied!!']"));
	}
	
	public WebElement homePageElement()
	{
		return PageUtil.findBy(By.xpath("//h4[text()='Stage']"));
	}
}
