package com.dms.stepdefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import com.dms.browserInstance.BrowserHandle;

import com.dms.logs.Logs;
import com.dms.pageobjects.LoginPOM;
import com.dms.utils.ReadFromProperty;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDef {

	LoginPOM loginPOM = new LoginPOM();

	@Given("User is on Login Page")
	public void user_is_on_login_page() throws IOException {
		Logs.logger.info(new Object() {
		}.getClass().getEnclosingMethod().getName());
		
		ReadFromProperty readFromProperty;
		Properties prop;
		readFromProperty = new ReadFromProperty();
		prop = readFromProperty.property();
		String output = prop.getProperty("url");
		BrowserHandle.getDriver().get(output);
		
	}
	
	@Then("Verify User is on Home Page")
	public void user_logged_in_is_on_home_page() {
		Logs.logger.info(new Object() {
		}.getClass().getEnclosingMethod().getName());
		BrowserHandle.wait.until(ExpectedConditions.elementToBeClickable(loginPOM.homePageElement()));
		Assert.assertTrue(loginPOM.homePageElement().isDisplayed());
	}
	
	@Then("Verify error message is displayed")
	public void verify_error_is_displayed() {
		Logs.logger.info(new Object() {
		}.getClass().getEnclosingMethod().getName());
		BrowserHandle.wait.until(ExpectedConditions.elementToBeClickable(loginPOM.accessDenied()));
		Assert.assertTrue(loginPOM.accessDenied().isDisplayed());
	}

	@When("User enters {string} and {string}")
	public void user_enters_and(String username, String password) throws InterruptedException {
		Logs.logger.info(new Object() {
		}.getClass().getEnclosingMethod().getName() + " username : " + username + " password : " + password);

		BrowserHandle.wait.until(ExpectedConditions.elementToBeClickable(loginPOM.email()));
		loginPOM.email().sendKeys(username + Keys.TAB);

		BrowserHandle.wait.until(ExpectedConditions.elementToBeClickable(loginPOM.password()));
		loginPOM.password().sendKeys(password + Keys.TAB);

	}

	
	@When("User click on login button")
	public void user_click_on_button() {
		
		BrowserHandle.wait.until(ExpectedConditions.elementToBeClickable(loginPOM.loginButton()));
		loginPOM.loginButton().click();
 
	}

	
}
